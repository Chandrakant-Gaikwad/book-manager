const books = [
  app.get("/books", (req, res) => {
  const data = require("./book.json");

  // Remove duplicates based on `id`
  const unique = data.filter(
    (book, index, self) =>
      index === self.findIndex((b) => b.id === book.id)
  );

  res.json(unique);
});

];

module.exports = books;
