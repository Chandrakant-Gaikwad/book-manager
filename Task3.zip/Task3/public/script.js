document.addEventListener('DOMContentLoaded', () => {
  const bookList = document.getElementById('bookList');
  const bookForm = document.getElementById('bookForm');
  const titleInput = document.getElementById('title');
  const authorInput = document.getElementById('author');

  // Load all books on page load
  const loadBooks = () => {
    fetch('/api/books')
      .then(res => res.json())
      .then(data => {
        bookList.innerHTML = '';
        data.forEach(book => {
          addBookToUI(book);
        });
      })
      .catch(err => {
        console.error('Failed to load books:', err);
      });
  };

  // Add new book to backend
  bookForm.addEventListener('submit', e => {
    e.preventDefault();
    const title = titleInput.value.trim();
    const author = authorInput.value.trim();

    if (!title || !author) return;

    fetch('/api/books', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title, author })
    })
      .then(res => res.json())
      .then(() => {
        titleInput.value = '';
        authorInput.value = '';
        loadBooks(); // ✅ Reload instead of manually adding
      });
  });

  // Delete book from backend and UI
  const deleteBook = id => {
    fetch(`/api/books/${id}`, { method: 'DELETE' })
      .then(res => res.json())
      .then(() => {
        loadBooks(); // ✅ Reload after delete
      });
  };

  // Helper: Render one book to UI
  const addBookToUI = book => {
    const li = document.createElement('li');
    li.innerHTML = `${book.title} by ${book.author}
      <button onclick="deleteBook(${book.id})">❌</button>`;
    bookList.appendChild(li);
  };

  window.deleteBook = deleteBook;

  loadBooks(); // Initial load
});
// script.js
const form = document.getElementById('bookForm');
const bookList = document.getElementById('bookList');

form.addEventListener('submit', function (e) {
  e.preventDefault();
  
  const title = document.getElementById('title').value.trim();
  const author = document.getElementById('author').value.trim();

  if (title && author) {
    const li = document.createElement('li');
    li.innerHTML = `<strong>${title}</strong> by ${author} 
      <button class="delete">Delete</button>`;

    // Delete button action
    li.querySelector('.delete').onclick = () => li.remove();

    bookList.appendChild(li);

    form.reset();
  }
});
